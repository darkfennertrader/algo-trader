"""
Example FastAPI microservice that validates:

1. Authorization: Bearer <internal Entra token>
2. X-User-Context: <signed JWT produced by APIM>

This example intentionally excludes OpenFGA.
The goal is to show what developers should do immediately
after receiving the "double token" from APIM.

Key idea:
- Bearer token = trust the caller service / gateway
- X-User-Context = trust the original end-user context
"""

from dataclasses import dataclass
from typing import Any, Dict, Optional

import jwt
from jwt import PyJWKClient
from jwt import InvalidTokenError, ExpiredSignatureError
from fastapi import FastAPI, Header, HTTPException, Depends


# ============================================================
# Configuration
# ============================================================
# In real code, move these values to environment variables,
# Azure App Configuration, Key Vault, or a config file.
#
# IMPORTANT:
# The values below are examples/placeholders.
# Replace them with your real issuer / audience / JWKS values.
# ============================================================

INTERNAL_ENTRA_ISSUER = "https://login.microsoftonline.com/<tenant-id>/v2.0"
INTERNAL_ENTRA_AUDIENCE = "api://my-internal-microservice"
INTERNAL_ENTRA_JWKS_URL = (
    "https://login.microsoftonline.com/<tenant-id>/discovery/v2.0/keys"
)

# This is the token created by APIM (or another trusted signer).
# Ideally APIM exposes a JWKS endpoint too.
APIM_USER_CONTEXT_ISSUER = "https://apim.mycompany.internal"
APIM_USER_CONTEXT_AUDIENCE = (
    "my-internal-microservice"  # optional but recommended
)
APIM_USER_CONTEXT_JWKS_URL = (
    "https://apim.mycompany.internal/.well-known/jwks.json"
)

# Restrict accepted algorithms.
# Never accept "alg" dynamically from the token without constraining it.
ALLOWED_ALGORITHMS = ["RS256"]


# ============================================================
# Simple security models
# ============================================================


@dataclass
class SecurityContext:
    """
    Object exposed to the endpoint after both tokens are validated.

    service_claims:
        Claims from the internal Entra bearer token.
        Used to understand/trust the upstream caller.

    user_claims:
        Claims from the APIM-signed user context JWT.
        Used to understand the original end user/customer.
    """

    service_claims: Dict[str, Any]
    user_claims: Dict[str, Any]


# ============================================================
# JWKS client cache
# ============================================================
# PyJWKClient already helps by fetching keys from JWKS.
# We wrap it with a tiny cache so we do not recreate the client
# on every request.
#
# In production, you may centralize this in a shared library.
# ============================================================

_jwks_clients: Dict[str, PyJWKClient] = {}


def get_jwks_client(jwks_url: str) -> PyJWKClient:
    """
    Return a cached PyJWKClient for the given JWKS URL.

    Why this matters:
    - JWT signature validation needs the issuer's public key.
    - For rotating keys, JWKS is the standard way to retrieve them.
    - We do not want to manually fetch JWKS in every endpoint.
    """
    if jwks_url not in _jwks_clients:
        _jwks_clients[jwks_url] = PyJWKClient(jwks_url)
    return _jwks_clients[jwks_url]


# ============================================================
# Helper functions
# ============================================================


def extract_bearer_token(authorization_header: str) -> str:
    """
    Extract the raw token from the Authorization header.

    Expected format:
        Authorization: Bearer <token>

    If the header is malformed, return 401.
    """
    if not authorization_header:
        raise HTTPException(
            status_code=401, detail="Missing Authorization header"
        )

    parts = authorization_header.strip().split()

    if len(parts) != 2 or parts[0].lower() != "bearer":
        raise HTTPException(
            status_code=401, detail="Invalid Authorization header format"
        )

    return parts[1]


def validate_jwt_with_jwks(
    token: str,
    jwks_url: str,
    issuer: str,
    audience: Optional[str],
    token_name: str,
) -> Dict[str, Any]:
    """
    Generic JWT validator.

    What it does:
    1. Reads token header and finds the signing key via JWKS
    2. Validates signature
    3. Validates issuer
    4. Validates audience (if configured)
    5. Validates expiration and standard time-based checks

    Why we use this:
    - Same logic works for:
      a) internal Entra bearer token
      b) APIM-signed user-context JWT

    Raises:
    - 401 if token is missing/invalid/expired
    """
    try:
        jwks_client = get_jwks_client(jwks_url)

        # Fetch the proper public signing key based on the token's "kid".
        signing_key = jwks_client.get_signing_key_from_jwt(token)

        # Build common validation options.
        decode_kwargs = {
            "jwt": token,
            "key": signing_key.key,
            "algorithms": ALLOWED_ALGORITHMS,
            "issuer": issuer,
        }

        # Audience can be optional for internal custom JWTs.
        # If your APIM token does not use "aud", set audience=None.
        if audience:
            decode_kwargs["audience"] = audience
        else:
            # If no audience is expected, explicitly disable audience validation.
            decode_kwargs["options"] = {"verify_aud": False}

        claims = jwt.decode(**decode_kwargs)

        return claims

    except ExpiredSignatureError:
        raise HTTPException(status_code=401, detail=f"{token_name} expired")

    except InvalidTokenError as ex:
        # Covers signature errors, issuer errors, audience errors, malformed token, etc.
        raise HTTPException(
            status_code=401, detail=f"Invalid {token_name}: {str(ex)}"
        )

    except Exception as ex:
        # Catch-all for unexpected issues like JWKS retrieval problems.
        raise HTTPException(
            status_code=401,
            detail=f"Failed to validate {token_name}: {str(ex)}",
        )


def validate_internal_entra_token(token: str) -> Dict[str, Any]:
    """
    Validate the internal Entra bearer token.

    This token proves:
    - the caller is trusted in the internal ecosystem
    - the token was issued by internal Entra
    - the token is intended for THIS microservice (audience check)

    Typical claims you may find:
    - iss
    - aud
    - exp
    - iat
    - appid / azp / oid / sub
    - scp or roles
    """
    return validate_jwt_with_jwks(
        token=token,
        jwks_url=INTERNAL_ENTRA_JWKS_URL,
        issuer=INTERNAL_ENTRA_ISSUER,
        audience=INTERNAL_ENTRA_AUDIENCE,
        token_name="internal Entra bearer token",
    )


def validate_user_context_token(token: str) -> Dict[str, Any]:
    """
    Validate the APIM-signed X-User-Context token.

    This token preserves the original end-user context.
    It should contain claims like:
    - sub            -> original user/customer id
    - role / mandate -> business role
    - tenant / org   -> tenant/customer context
    - idp            -> original identity provider
    - amr            -> authentication method reference

    IMPORTANT:
    Never trust this header without validating the JWT signature.
    """
    return validate_jwt_with_jwks(
        token=token,
        jwks_url=APIM_USER_CONTEXT_JWKS_URL,
        issuer=APIM_USER_CONTEXT_ISSUER,
        audience=APIM_USER_CONTEXT_AUDIENCE,
        token_name="X-User-Context token",
    )


def build_user_context(user_claims: Dict[str, Any]) -> Dict[str, Any]:
    """
    Map raw JWT claims into a clean internal structure.

    Why this is useful:
    - endpoint/business code should not depend on token-specific naming
    - if APIM changes claim names later, only this function may need updates

    The exact claim names depend on how APIM generates the user-context JWT.
    Below we show a flexible mapping.
    """
    return {
        # stable user identifier
        "user_id": user_claims.get("sub"),
        # business attributes
        "role": user_claims.get("role"),
        "mandate": user_claims.get("mandate"),
        # tenancy/customer scoping
        "tenant": user_claims.get("tenant") or user_claims.get("org"),
        # useful tracing/context claims
        "idp": user_claims.get("idp"),
        "amr": user_claims.get("amr"),
        # keep full raw claims if business logic needs them later
        "raw": user_claims,
    }


def validate_required_user_context_fields(user_context: Dict[str, Any]) -> None:
    """
    Enforce a minimum set of fields required by this API.

    This is optional but strongly recommended.
    For example, if your API cannot work without user_id and tenant,
    fail early.

    You can make this stricter depending on your use case.
    """
    required = ["user_id", "tenant"]
    missing = [field for field in required if not user_context.get(field)]

    if missing:
        raise HTTPException(
            status_code=401,
            detail=f"Missing required user context fields: {', '.join(missing)}",
        )


# ============================================================
# FastAPI dependency
# ============================================================


def get_security_context(
    authorization: str = Header(..., alias="Authorization"),
    x_user_context: str = Header(..., alias="X-User-Context"),
) -> SecurityContext:
    """
    FastAPI dependency executed before the endpoint.

    This is where the microservice performs the two validations.

    Flow:
    1. Extract bearer token from Authorization header
    2. Validate internal Entra token
    3. Validate X-User-Context token
    4. Return a normalized SecurityContext

    If anything fails, the request is rejected before business logic runs.
    """

    # --------------------------------------------------------
    # 1. Parse Authorization header
    # --------------------------------------------------------
    bearer_token = extract_bearer_token(authorization)

    # --------------------------------------------------------
    # 2. Validate internal service token
    # --------------------------------------------------------
    service_claims = validate_internal_entra_token(bearer_token)

    # --------------------------------------------------------
    # 3. Validate APIM user-context token
    # --------------------------------------------------------
    user_claims = validate_user_context_token(x_user_context)

    # --------------------------------------------------------
    # 4. Normalize / validate user context
    # --------------------------------------------------------
    user_context = build_user_context(user_claims)
    validate_required_user_context_fields(user_context)

    return SecurityContext(
        service_claims=service_claims,
        user_claims=user_context,
    )


# ============================================================
# FastAPI application
# ============================================================

app = FastAPI(title="Microservice with double-token validation")


@app.get("/health")
def health() -> Dict[str, str]:
    """
    Simple public endpoint for health checks.
    Normally this may be excluded from auth depending on your setup.
    """
    return {"status": "ok"}


@app.get("/claims/{claim_id}")
def get_claim(
    claim_id: str,
    security: SecurityContext = Depends(get_security_context),
) -> Dict[str, Any]:
    """
    Example protected endpoint.

    By the time we reach this function:
    - the internal Entra bearer token is already validated
    - the X-User-Context JWT is already validated
    - claims are available in a normalized object

    This endpoint intentionally does NOT call OpenFGA,
    because you asked to exclude it.

    In real life, this is the place where you would:
    - do resource-level authorization if needed
    - load data
    - apply tenant scoping
    """

    user = security.user_claims
    caller = security.service_claims

    # Example of tenant/user-aware business behavior:
    # The microservice should use the user context to scope the data.
    #
    # In real code, your repository/service layer would use:
    # - claim_id
    # - tenant
    # - user role / mandate
    #
    # to fetch only the right data.
    return {
        "message": "Token validation succeeded",
        "claim_id": claim_id,
        # End-user context (from X-User-Context)
        "end_user": {
            "user_id": user["user_id"],
            "tenant": user["tenant"],
            "role": user.get("role"),
            "mandate": user.get("mandate"),
            "idp": user.get("idp"),
        },
        # Caller/service context (from internal Entra bearer token)
        "caller_service": {
            "issuer": caller.get("iss"),
            "audience": caller.get("aud"),
            "subject": caller.get("sub"),
            "azp": caller.get("azp"),  # authorized party, if present
            "appid": caller.get("appid"),  # app id, if present
        },
    }
